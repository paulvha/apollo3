# Android- BLE SPS30

Example application that allows you to scan, and connect to a ble device on Android (M) API 23

After connecting to a peripheral Arduino Sketch 'example23_ph_sps30', it will present buttons. You can either request
<br> request SPS30 results
<br> request SPS30 to clean
<br> request SPS30 to sleep
<br> request SPS30 to wakeup
<br> disconnect

version 1.0 / January 2023 / paulvha

