# Android-ble-led-relay

Example application that allows you to scan, and connect to a ble device on Android (M) API 23

After connecting to a peripheral Arduino Sketch 'Output_Input_control', it will present buttons. You can either request
<br> setting the Arduino Onboard led on/off
<br> switch 2 output pins between HIGH / LOW
<br> get the input from a digital pin
<br> get the input from an Analog pin
<br> ask for regular update of simulated battery level

version 1.0 / December 2022 / paulvha

