/*
 *
 *  GattLib - GATT Library
 *
 *  Copyright (C) 2016-2017  Olivier Martin <olivier@labapart.org>
 *
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 *  ============================================================================
 *
 *  paulvha / December 2022 / version 1.0:
 *
 *  Based on the example notification.c, created an extended version
 *  to work with the output_input_control sketch that is part of ArduinoBLE_P.
 *
 *  You can set on an Arduino on the command line or interactive menu
 * 		2 output pins low or high,
 *  	The LED on or off
 *    Read 1 digital input pin
 *    Read 1 analog input pin
 * 		Request to send regulare a simulated battery level (menu only)
 *
 *  It will receive the measured data over notifications.
 *
 *  You can provide the BLE address OR just the devicename as advertised. For all options
 *  see usage() or use the '-h'  option with the binary
 *
 *  It will take keyboard input to be send to the BME280 sketch to change some parameters
 *  To exit : q + <enter> or press 'control + C'
 *
 */

# include <assert.h>
# include <glib.h>
# include <stdio.h>
# include <stdlib.h>
# include <signal.h>
# include <getopt.h>
# include "gattlib.h"
# include <stdbool.h>
# include <time.h>

// UUID's
char *ledService = "19B10000-E8F2-537E-4F6C-D104768A1214";					// not used info only
char *switchCharacteristic = "19B10001-E8F2-537E-4F6C-D104768A1214"; // this is receive on peripheral for commands
char *LevelChar = "19B10002-E8F2-537E-4F6C-D104768A1214";						 // this is send on peripheral (notify)

// default devicename if NO BLE address or devicename provided on command line
char *default_dev_name = "Output_Input_Control";

// BLE related info
static uuid_t s_uuid, r_uuid;
gatt_connection_t* connection = NULL;
GMainLoop* loop = NULL;
void* adapter = NULL;
char* dev_addr = NULL;
char* dev_name = NULL;
bool dev_discovered = false;	// true = peripheral device is detected
bool SHOW_scan = true;			  // true = show all scan discovered devices
int timeout = 10;				      // default scantime in seconds

// sketch control related input
#define MAXOUTPUT 2					// store output setting for 2 pins
int SetOutputindex = 0;			// keep track of entries used
char* SetOutput[MAXOUTPUT]; // store output setting for 2 pins

int DigInput = 0;
int AnaInput = 0;
char* LedOutput = NULL;

// define commands from remote / central
#define CmdLedOn    0x31
#define CmdLedOff   0x30
#define CmdOut1On   0x11
#define CmdOut1Off  0x10
#define CmdOut2On   0x21
#define CmdOut2Off  0x20
#define CmdBatOn    0x41
#define CmdBatOff   0x40
#define CmdIn1Rd    0x51  // read input digital pin1
#define CmdAn1Rd    0x61  // read input analog pin1

/**
 * Display valid command options to send to sketch
 */
void display_menu()
{
	fprintf(stderr,"1.  Set output pin 1 on\n");
	fprintf(stderr,"2.  Set output pin 1 off\n");
	fprintf(stderr,"3.  Set output pin 2 on\n");
	fprintf(stderr,"4.  Set output pin 2 off\n");
	fprintf(stderr,"5.  Set onboard LED on\n");
	fprintf(stderr,"6.  Set onboard LED off\n");
	fprintf(stderr,"7.  Get digital pin 1 input\n");
	fprintf(stderr,"8.  Get Analog pin 1 input\n");
	fprintf(stderr,"9.  Request START sending simulated battery\n");
	fprintf(stderr,"10. Request STOP sending simulated battery\n\n");

	fprintf(stderr,"q.  Quit this program\n\n");
}

/**
 * call back if device is discovered
 *
 * if dev_name provided, try to retrieve the BLE address
 * if dev_addr provided, check device can be found
 */
static void ble_discovered_device(const char* addr, const char* name) {

	// If device is not discovered, but we have a dev_addr
	// this address was provided on the command line.
	// We check for match to make sure the peripheral is in reach.
	if (! dev_discovered && dev_addr != NULL) {

		if (strcmp(addr,dev_addr) == 0) {
			if (name) fprintf(stderr, "FOUND '%s': '%s'.\n", addr, name);
			else fprintf(stderr, "FOUND device '%s'.\n", addr);
			dev_discovered = true;
			return;
		}
	}

	// if scanned device has a name
	if (name) {

		// if devicename was provided and not found yet
		if (dev_name && ! dev_discovered) {
			// try to get BLE address of the devicename we are looking for
			if (strcmp(name,dev_name) == 0) {
				fprintf(stderr, "FOUND '%s' on '%s'.\n",name, addr);
				dev_addr = strdup(addr);
				dev_discovered = true;
			}
		}
		else if (SHOW_scan)
			fprintf(stderr,"Discovered %s - '%s'.\n",name, addr);

	} else if (SHOW_scan)
		fprintf(stderr,"Discovered '%s'.\n", addr);
}

/**
 * Start scanning for the device either based on provided BLE address
 * or else look for dev_name and store the BLE the address
 */
int Find_device(){
	int ret;

	ret = gattlib_adapter_open(NULL, &adapter);
	if (ret) {
		fprintf(stderr, "ERROR: Failed to open adapter.\n");
		return -1;
	}

	if (dev_name) fprintf(stderr,"Start scanning for '%s' (%d seconds)\n\n", dev_name, timeout);
	else fprintf(stderr,"Start scanning for '%s' (%d seconds)\n\n", dev_addr, timeout);

	ret = gattlib_adapter_scan_enable(adapter, ble_discovered_device, timeout);

	if (ret) {
		fprintf(stderr, "ERROR: Failed to scan.\n");
		return -1;
	}

	gattlib_adapter_scan_disable(adapter);

	fprintf(stderr,"Scan completed.\n");

	return 0;
}

/**
 * This will be called when a notification is arriving
 */
void notification_handler(const uuid_t* uuid, const uint8_t* data, size_t data_length, void* user_data)
{
	uint8_t command = data[0];

#if (0)
	/***** below left in for debug ****/
	printf("Notification Handler: ");

	// add the UUID
	char uuid_str[MAX_LEN_UUID_STR + 1];
	gattlib_uuid_to_string(uuid, uuid_str, sizeof(uuid_str));
	printf("UUID %s: ", uuid_str);

	// DEBUG : display data raw
	for (int j = 0; j < data_length; j++) {
		printf("%02x ", data[j]);
	}
	printf("\n");

	//gattlib_rssi(connection);
  /********* end of debug ***********/
#endif
	if (command == CmdIn1Rd ){      // read digital pin 1
		printf("Digital pin 1 is %s\n",data[1] ? "HIGH":"LOW");
	}
	else if (command == CmdAn1Rd ){ // read analog pin 1
		uint16_t val = data[1] << 8 | data[2];
		printf("Analog pin 1 value is %d\n",val);
	}
	else if (command == CmdBatOn){ // simulated battery
		printf("Simulated battery value is %d%%\n",data[1]);
	}
	else
		fprintf(stderr, "Unknown notification %x\n",command);
}

/**
 * usage
 */
static void usage(char *argv[]) {
	fprintf(stderr, "BLE options\n");
	fprintf(stderr, "%s  [-a adapter] [-b address] [-d devicename] [-t scan timeout] [-s] [-r]\n", argv[0]);
	fprintf(stderr, "-a  option to provide local BLE adapter name. \n");
	fprintf(stderr, "-b  provide the remote BLE address instead of name.\n");
	fprintf(stderr, "-d  provide the remote BLE devicename instead of address.\n");
	fprintf(stderr, "-s  will only display scan result for device found.\n");
	fprintf(stderr, "-t  set scan timeout (default %d seconds)\n", timeout);
	fprintf(stderr, "\nif NO device name and no address the default devicename is '%s'\n", default_dev_name);

	fprintf(stderr, "Sketch control options\n");
	fprintf(stderr, "-A 1  Get Analog input pin1.\n");
	fprintf(stderr, "-D 1  Get Digital input pin1.\n");

	fprintf(stderr, "-O on1  Set output pin1 on\n");
	fprintf(stderr, "-O off1 Set output pin1 off\n");

	fprintf(stderr, "-O on2  Set output pin2 on\n");
	fprintf(stderr, "-O off2 Set output pin2 off\n");

	fprintf(stderr, "-L on  Set LED on\n");
	fprintf(stderr, "-L off Set LED off\n");
	exit(-1);
}

/**
 * close out correctly
 * @param ret : the exit value
 */
void cleanup(int ret) {

	// if called when loop is not active
	if (! loop) {

		// check that a connection needs to be cancelled
		if (connection) {

			// this can cause a warning that can be ignored
			gattlib_disconnect(connection,true);
		}

		fprintf(stderr,"Bye, exit code: %d\n", ret);
		exit(ret);
	}
	else // stop loop first
		g_main_loop_quit(loop);
}

/**
 * This will be called when peripheral disconnected
 */
void disconnect_handler(gatt_connection_t* connection) {
	fprintf(stderr,"Peripheral disconnected.\n");
	cleanup(6);
}

/**
 * this is called when contrl-C is pressed on the keyboard
 */
void my_signal_handler(int s){
   //fprintf(stderr,"Caught signal %d\n", s);
   cleanup(0);
}

/**
 * Send a command and display which command
 */
void Sendcmd(int cmd)
{
	switch(cmd){
			case CmdOut1On:
				fprintf(stderr,"Set Output pin 1 on.\n");
				break;
			case CmdOut1Off:
				fprintf(stderr,"Set Output pin 1 off.\n");
				break;
			case CmdOut2On:
				fprintf(stderr,"Set Output pin 2 on.\n");
			  break;
			case CmdOut2Off:
				fprintf(stderr,"Set Output pin 2 off.\n");
			  break;
			case CmdLedOn:
				fprintf(stderr,"Set LED on.\n");
				break;
			case CmdLedOff:
				fprintf(stderr,"Set LED off.\n");
			  break;
			case CmdIn1Rd:
				fprintf(stderr,"Get Digital pin 1 status.\n");
			  break;
			case CmdAn1Rd:
				fprintf(stderr,"Get Analog pin 1 status.\n");
			  break;
			case CmdBatOn:
				fprintf(stderr,"Start simulated battery level.\n");
			  break;
			case CmdBatOff:
				fprintf(stderr,"Stop simulated battery level.\n");
			  break;

			default :
				fprintf(stderr,"Unknown request ox%x.\n", cmd);
				return;
				break;
	}

	int ret = gattlib_write_char_by_uuid(connection, &s_uuid, &cmd, 1);

	if (ret) {
		fprintf(stderr, "Failed to send request.\n");
		//cleanup(4);
	}
}

/**
 * Process keyboard input
 */
static gboolean
handle_keyboard (GIOChannel * source, GIOCondition cond)
{
	gchar *str = NULL;

	if (g_io_channel_read_line (source, &str, NULL, NULL,
	  NULL) != G_IO_STATUS_NORMAL) {
		return TRUE;
	}

	// requesting to stop
	if (str[0] == 'q' || str[0] == 'Q') {
		cleanup(0);
	}
	// if only <enter>
	else if (str[0] == 0x0a) {
		display_menu();
	}
	// otherwise send it
	else {
		int sel = atoi(str);

		switch(sel) {
			case 1:	Sendcmd(CmdOut1On);  break;
			case 2:	Sendcmd(CmdOut1Off); break;
			case 3:	Sendcmd(CmdOut2On);  break;
			case 4:	Sendcmd(CmdOut2Off); break;
			case 5:	Sendcmd(CmdLedOn);   break;
			case 6:	Sendcmd(CmdLedOff);  break;
			case 7:	Sendcmd(CmdIn1Rd);   break;
			case 8:	Sendcmd(CmdAn1Rd);   break;
			case 9:	Sendcmd(CmdBatOn);   break;
			case 10:Sendcmd(CmdBatOff);  break;
			default:
				fprintf(stderr,"Illegal selection %d\n",sel);
				break;
		}
	}

	g_free (str);

	return TRUE;
}

/**
 * handle any of the options provided on the command line
 */
void HandleCommandLineRequests()
{
	char pin;

	// any OUTPUT request (like on1 or off1)
	for (uint8_t i = 0 ; i < SetOutputindex ;i++) {

		pin = SetOutput[i][sizeof(SetOutput[i]) -1];
		SetOutput[i][sizeof(SetOutput[i])-1] = 0x0;
		if (strcmp(SetOutput[i], "on") == 0) {
			if (pin == '1')	Sendcmd(CmdOut1On);
			else Sendcmd(CmdOut1Off);
		}
		else {
			if (pin == '2')	Sendcmd(CmdOut2On);
			else Sendcmd(CmdOut2Off);
		}
	}

	// LED output request ?
	if (LedOutput != NULL) {
		if (strcmp(LedOutput, "on") == 0) 	Sendcmd(CmdLedOn);
		else Sendcmd(CmdLedOff);
	}

	// digital input request ?
	if (DigInput != 0) {
			if (DigInput == 1) Sendcmd(CmdIn1Rd);
	}

	// Analog input request?
	if (AnaInput != 0) {
			if (AnaInput == 1) Sendcmd(CmdAn1Rd);
	}
}

/**
 * here the joy begins
 */
int main(int argc, char *argv[]) {
	int ret, opt;
	GIOChannel *io_stdin;

	// capture cntrl-c
	signal (SIGINT,my_signal_handler);

	/* parse commandline */
    while ((opt = getopt(argc, argv, "a:b:d:t:shA:D:O:L:")) != -1)
    {
		switch (opt) {
			case 'a':   // adapter
				adapter = strdup(optarg);
				break;

			case 'b':   // provided BLE address
				if (dev_name) {
					fprintf(stderr, "Provide EITHER peripheral devicename or BLE address. NOT both.\n");
					exit(-1);
				}
				dev_addr = strdup(optarg);
				break;

			case 'd':	// devicename to look for
				if (dev_addr) {
					fprintf(stderr, "Provide EITHER peripheral devicename or BLE address. Not both.\n");
					exit(-1);
				}
				dev_name = strdup(optarg);
				break;

			case 't':	// set scan timeout
				timeout = (int) strtod(optarg, NULL);
				if (timeout == 0) {
					fprintf(stderr, "%d invalid timeout.\n", timeout);
					exit(-1);
				}
				break;

			case 's':	// set to reduce scan results display
				SHOW_scan = 0;
				break;

			case 'D':	// Get digital input pin
				DigInput = (int) strtod(optarg, NULL);
				break;

			case 'A':	// Get Analog input pin
				AnaInput = (int) strtod(optarg, NULL);
				break;

			case 'L':	// Get Analog input pin
				LedOutput = strdup(optarg);
				break;

			case 'O':   // perform output on a pin
				if (SetOutputindex < MAXOUTPUT){
					SetOutput[SetOutputindex] = strdup(optarg);
					SetOutputindex++;
				}
				else{
					fprintf(stderr, "Can only add output instruction for %d pins\n", MAXOUTPUT -1);
					exit(-1);
				}
				break;

			case 'h':	// help
				usage(argv);
				break;

			default:
				fprintf(stderr, "Unknown option %d.\n", opt);
				usage(argv);
				break;
		}
    }

	// if no BLE address
	if (! dev_addr) {
		// AND no devicename : use default devicename
		if (! dev_name) dev_name = strdup(default_dev_name);
	}

	// set keyboard handling
	io_stdin = g_io_channel_unix_new (fileno (stdin));
	g_io_add_watch (io_stdin, G_IO_IN, (GIOFunc) handle_keyboard, NULL);

	// UUID receive notifications
	if (gattlib_string_to_uuid(LevelChar, 36 + 1, &r_uuid) < 0) {
		fprintf(stderr, "Can not translate notify characteristic.\n");
		exit(1);
	}

	// UUID send commands
	if (gattlib_string_to_uuid(switchCharacteristic, 36 + 1, &s_uuid) < 0) {
		fprintf(stderr, "Can not translate send characteristic.\n");
		exit(1);
	}

	// look for device by name
	ret = Find_device();
	if (ret) exit(1);

	if (! dev_discovered){
		if (dev_addr) fprintf(stderr,"Device with address '%s' was NOT discovered.\n", dev_addr);
		else fprintf(stderr,"Device with name '%s' was NOT discovered.\n", dev_name);
		exit(2);
	}

	fprintf(stderr,"Trying to connect.\n");

	connection = gattlib_connect(NULL, dev_addr, BDADDR_LE_PUBLIC, BT_SEC_LOW, 0, 0);
	if (connection == NULL) {
		if (dev_addr) fprintf(stderr,"Fail to connect to the bluetooth device %s.\n", dev_addr);
		else fprintf(stderr,"Fail to connect to the bluetooth device %s.\n",dev_name);
		exit(3);
	}

	fprintf(stderr,"Connected.\n");

	// register disconnect call back
	ret = gattlib_register_disconnect(connection, disconnect_handler);
	if (ret) {
		fprintf(stderr, "Fail to set disconnect callback.\n");
		cleanup(4);
	}

	// set notification call back
	gattlib_register_notification(connection, notification_handler, NULL);

	// enable notifications
	ret = gattlib_notification_start(connection, &r_uuid);
	if (ret) {
		fprintf(stderr, "Fail to start notification.\n");
		cleanup(5);
	}

	HandleCommandLineRequests();

	// display interactive menu
	display_menu();

	fprintf(stderr, "Started notification. Waiting for data.\n");

	loop = g_main_loop_new(NULL, 0);
	g_main_loop_run(loop);

	// we are done
	fprintf(stderr, "Ending program\n");
	g_main_loop_unref(loop);
	loop = NULL;
	cleanup(0);
}
